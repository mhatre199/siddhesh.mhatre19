package com.example.demo.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "medicines_assigned")
public class MedicineAssigned {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String prescription;

	private int medicineQty;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "pat_id")
	private Patient patient;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "medicine_id")
	private Medicine medicine;

	public MedicineAssigned(int id, Patient patient, Medicine medicine, String prescription, int medicineQty) {
		super();
		this.id = id;
		this.patient = patient;
		this.medicine = medicine;
		this.prescription = prescription;
		this.medicineQty = medicineQty;
	}

	public MedicineAssigned() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public Medicine getMedicine() {
		return medicine;
	}

	public void setMedicine(Medicine medicine) {
		this.medicine = medicine;
	}

	public String getPrescription() {
		return prescription;
	}

	public void setPrescription(String prescription) {
		this.prescription = prescription;
	}

	public int getMedicineQty() {
		return medicineQty;
	}

	public void setMedicineQty(int medicineQty) {
		this.medicineQty = medicineQty;
	}

	@Override
	public String toString() {
		return "MedicineAssigned [id=" + id + ", patient=" + patient + ", medicine=" + medicine + ", prescription="
				+ prescription + ", medicineQty=" + medicineQty + "]";
	}

}
