package com.example.demo.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "wards")
public class Ward {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String type;

	private double charges;

	private double availability;
	private double maxCapacity;

	@OneToMany(mappedBy = "ward", cascade = CascadeType.PERSIST)
	private List<Patient> patients;

	public Ward(int id, String type, double charges, double availability, double maxCapacity, List<Patient> patients) {
		super();
		this.id = id;
		this.type = type;
		this.charges = charges;
		this.availability = availability;
		this.maxCapacity = maxCapacity;
		this.patients = patients;
	}

	public Ward() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getCharges() {
		return charges;
	}

	public void setCharges(double charges) {
		this.charges = charges;
	}

	public double getAvailability() {
		return availability;
	}

	public void setAvailability(double availability) {
		this.availability = availability;
	}

	public double getMaxCapacity() {
		return maxCapacity;
	}

	public void setMaxCapacity(double maxCapacity) {
		this.maxCapacity = maxCapacity;
	}

	public List<Patient> getPatients() {
		return patients;
	}

	public void setPatients(List<Patient> patients) {
		this.patients = patients;
	}

	@Override
	public String toString() {
		return "Ward [id=" + id + ", type=" + type + ", charges=" + charges + ", availability=" + availability
				+ ", maxCapacity=" + maxCapacity + ", patients=" + patients + "]";
	}

}
