package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.MedicineAssigned;
import com.example.demo.service.MedicineAssignedService;

@RestController
@RequestMapping("/MedicineAssignedController")
public class MedicineAssignedController {

	@Autowired
	private MedicineAssignedService medicineAssignedService;

	@GetMapping("/getAllMedicineAssigneds")
	public List<MedicineAssigned> getAllMedicineAssigneds() {

		return medicineAssignedService.getAllMedicineAssigneds();
	}

	@PostMapping("/saveMedicineAssigned")
	public MedicineAssigned saveMedicineAssigned(@RequestBody MedicineAssigned medicineAssigned) {

		return medicineAssignedService.saveMedicineAssigned(medicineAssigned);
	}

	
	
	@PutMapping("/updateMedicineAssigned/{id}")
	public MedicineAssigned updateMedicineAssigned(@PathVariable("id") Integer id,
			@RequestBody MedicineAssigned medicineAssigned)
	{	
		medicineAssigned.setId(id);
		MedicineAssigned updateMedicineAssigned=medicineAssignedService.saveMedicineAssigned(medicineAssigned);
		
		return updateMedicineAssigned;
	}
	
	
	
	@DeleteMapping("/deleteMedicineAssigned/{id}")
	public void deleteMedicineAssigned(@PathVariable ("id") Integer id) {
		
		medicineAssignedService.deleteMedicineAssigned(id);
		
	}
	
	
	@GetMapping("/getMedicineAssignedById/{id}")
	public MedicineAssigned getMedicineAssignedById(@PathVariable ("id") Integer id) {
		
		MedicineAssigned medicineAssigned=medicineAssignedService.getMedicineAssignedById(id);
		return medicineAssigned;
	}
	
	
	
	
	
	
	

}
