package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Medicine;
import com.example.demo.repository.MedicineRepository;

@Service
public class MedicineService {

	@Autowired
	private MedicineRepository medicineRepository;

	public List<Medicine> getAllMedicines() {
		return medicineRepository.findAll();
	}

	public Medicine saveMedicine(Medicine medicine) {

		return medicineRepository.save(medicine);
	}

	public Medicine updateMedicine(Medicine medicine) {

		Medicine existingMedicine = medicineRepository.findById(medicine.getId()).get();

		existingMedicine.setName(medicine.getName());
		existingMedicine.setPrice(medicine.getPrice());

		Medicine updateMedicine = medicineRepository.save(existingMedicine);

		return updateMedicine;
	}
	
	
	public void deleteMedicine(Integer id) {
		
		medicineRepository.deleteById(id);
	}
	
	
	public Medicine getMedicineById(Integer id) {
		
		Optional<Medicine> optionalid=medicineRepository.findById(id);
		
		return optionalid.get();
	}
	

}
