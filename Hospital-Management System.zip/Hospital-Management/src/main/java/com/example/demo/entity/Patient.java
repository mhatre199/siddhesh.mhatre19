package com.example.demo.entity;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class Patient {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String pName;

	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dateOfAdmission;
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dob;

	private String gender;

	private String bloodGroup;
	private String prescription;
	private int bedAlloted;
	private String paymentStatus;
	private String patientProblem;
	private String address;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id")
	private User user;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "ward_id")
	private Ward ward;

	@OneToMany(mappedBy = "patient", cascade = CascadeType.ALL)
	// private List<DoctorVisit> visits;
	private List<DoctorVisit> visits;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "doctor_id")
	private Doctor doctor;

	@OneToMany(mappedBy = "patient", cascade = CascadeType.ALL)
	private List<MedicineAssigned> medicines;

	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Patient(int id, String pName, Date dateOfAdmission, Date dob, String gender, String bloodGroup,
			String prescription, int bedAlloted, String paymentStatus, String patientProblem, String address, User user,
			Ward ward, List<DoctorVisit> visits, Doctor doctor, List<MedicineAssigned> medicines) {
		super();
		this.id = id;
		this.pName = pName;
		this.dateOfAdmission = dateOfAdmission;
		this.dob = dob;
		this.gender = gender;
		this.bloodGroup = bloodGroup;
		this.prescription = prescription;
		this.bedAlloted = bedAlloted;
		this.paymentStatus = paymentStatus;
		this.patientProblem = patientProblem;
		this.address = address;
		this.user = user;
		this.ward = ward;
		this.visits = visits;
		this.doctor = doctor;
		this.medicines = medicines;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public Date getDateOfAdmission() {
		return dateOfAdmission;
	}

	public void setDateOfAdmission(Date dateOfAdmission) {
		this.dateOfAdmission = dateOfAdmission;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getPrescription() {
		return prescription;
	}

	public void setPrescription(String prescription) {
		this.prescription = prescription;
	}

	public int getBedAlloted() {
		return bedAlloted;
	}

	public void setBedAlloted(int bedAlloted) {
		this.bedAlloted = bedAlloted;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getPatientProblem() {
		return patientProblem;
	}

	public void setPatientProblem(String patientProblem) {
		this.patientProblem = patientProblem;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Ward getWard() {
		return ward;
	}

	public void setWard(Ward ward) {
		this.ward = ward;
	}

	public List<DoctorVisit> getVisits() {
		return visits;
	}

	public void setVisits(List<DoctorVisit> visits) {
		this.visits = visits;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	public List<MedicineAssigned> getMedicines() {
		return medicines;
	}

	public void setMedicines(List<MedicineAssigned> medicines) {
		this.medicines = medicines;
	}

	@Override
	public String toString() {
		return "Patient [id=" + id + ", pName=" + pName + ", dateOfAdmission=" + dateOfAdmission + ", dob=" + dob
				+ ", gender=" + gender + ", bloodGroup=" + bloodGroup + ", prescription=" + prescription
				+ ", bedAlloted=" + bedAlloted + ", paymentStatus=" + paymentStatus + ", patientProblem="
				+ patientProblem + ", address=" + address + ", user=" + user + ", ward=" + ward + ", visits=" + visits
				+ ", doctor=" + doctor + ", medicines=" + medicines + "]";
	}

}
