package com.example.demo.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "doctors")
public class Doctor { 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private double charges;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "emp_id")
	private Employee employee;

	@OneToMany(mappedBy = "doctor", cascade = CascadeType.PERSIST)
	private List<Patient> patients;

	@OneToMany(mappedBy = "doctor", cascade = CascadeType.PERSIST)
	private List<DoctorVisit> visits;

	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Doctor(int id, Employee employee, double charges, List<Patient> patients, List<DoctorVisit> visits) {
		super();
		this.id = id;
		this.employee = employee;
		this.charges = charges;
		this.patients = patients;
		this.visits = visits;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public double getCharges() {
		return charges;
	}

	public void setCharges(double charges) {
		this.charges = charges;
	}

	public List<Patient> getPatients() {
		return patients;
	}

	public void setPatients(List<Patient> patients) {
		this.patients = patients;
	}

	public List<DoctorVisit> getVisits() {
		return visits;
	}

	public void setVisits(List<DoctorVisit> visits) {
		this.visits = visits;
	}

	@Override
	public String toString() {
		return "Doctor [id=" + id + ", employee=" + employee + ", charges=" + charges + ", patients=" + patients
				+ ", visits=" + visits + "]";
	}

}
