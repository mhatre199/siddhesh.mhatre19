package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Doctor;
import com.example.demo.repository.DoctorRepository;

@Service
public class DoctorService {

	@Autowired
	private DoctorRepository doctorRepository;

	public List<Doctor> getAllDoctors() {

		return doctorRepository.findAll();
	}

	public Doctor saveDoctor(Doctor doctor) {

		return doctorRepository.save(doctor);
	}

	public Doctor updateDoctor(Doctor doctor) {

		Doctor existingUpdate = doctorRepository.findById(doctor.getId()).get();

		existingUpdate.setCharges(doctor.getCharges());

		Doctor updateDoctor = doctorRepository.save(existingUpdate);

		return updateDoctor;
	}

	public void deleteDoctor(Integer id) {

		doctorRepository.deleteById(id);
	}

	public Doctor getDoctorById(Integer id) {
		Optional<Doctor> optionalid = doctorRepository.findById(id);

		return optionalid.get();
	}

}
