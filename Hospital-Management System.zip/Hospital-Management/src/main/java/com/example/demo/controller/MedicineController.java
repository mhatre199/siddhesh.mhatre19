package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Medicine;
import com.example.demo.service.MedicineService;

@RestController
@RequestMapping("/medicineController")
public class MedicineController {

	@Autowired
	private MedicineService medicineService;
	
	
	@GetMapping("/getAllMedicines")
	public List<Medicine> getAllMedicines(){
		
		return medicineService.getAllMedicines();
	}
	
	
	
	@PostMapping("/saveMedicine")
	public Medicine saveMedicine(@RequestBody Medicine medicine)
	{
		return medicineService.saveMedicine(medicine);
	}
	
	
	
	@PutMapping("/updateMedicine/{id}")
	public Medicine updateMedicine(@PathVariable("id") Integer id,@RequestBody Medicine medicine) {
		
		medicine.setId(id);
		
		Medicine updateMedicine=medicineService.updateMedicine(medicine);
		return updateMedicine;
	}
	
	@DeleteMapping("/deleteMedicine/{id}")
	public void deleteMedicine(@PathVariable("id") Integer id)
	{
		medicineService.deleteMedicine(id);
	}
	
	
	@GetMapping("/getMedicineById/{id}")
	public Medicine getMedicineById(@PathVariable ("id") Integer id)
	{
		
		Medicine medicine =medicineService.getMedicineById(id);
		return medicine;
	}
	
	
	
	
	
	
}
