package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Ward;
import com.example.demo.repository.WardRepository;

@Service
public class WardService {

	@Autowired
	private WardRepository wardRepository;

	public List<Ward> getAllWards() {

		return wardRepository.findAll();
	}

	public Ward saveWard(Ward ward) {

		return wardRepository.save(ward);

	}

	public Ward updateWard(Ward ward) {

		Ward existingWard = wardRepository.findById(ward.getId()).get();

		existingWard.setType(ward.getType());
		existingWard.setCharges(ward.getCharges());
		existingWard.setAvailability(ward.getAvailability());
		existingWard.setMaxCapacity(ward.getAvailability());

		Ward updateWard = wardRepository.save(existingWard);

		return updateWard;
	}

	public void deleteWard(Integer id) {

		wardRepository.deleteById(id);
	}
	
	
	public Ward getWardById(Integer id) {
		
		Optional<Ward> optionalid=wardRepository.findById(id);
		
		return optionalid.get();
	}
	
	
	

}
