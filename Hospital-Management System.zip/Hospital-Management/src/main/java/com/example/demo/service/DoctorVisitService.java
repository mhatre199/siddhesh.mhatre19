package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.DoctorVisit;
import com.example.demo.repository.DoctorVisitRepository;

@Service
public class DoctorVisitService {

	@Autowired
	private DoctorVisitRepository doctorVisitRepository;

	public List<DoctorVisit> getAllDoctorVisits() {
		return doctorVisitRepository.findAll();
	}

	public DoctorVisit saveDoctorVisit(DoctorVisit doctorVisit) {

		return doctorVisitRepository.save(doctorVisit);
	}

	public DoctorVisit DoctorVisit(DoctorVisit doctorVisit) {

		DoctorVisit existingDoctorVisit = doctorVisitRepository.findById(doctorVisit.getId()).get();

		existingDoctorVisit.setVdrName(doctorVisit.getVdrName());

		DoctorVisit updateDoctorVisit = doctorVisitRepository.save(existingDoctorVisit);

		return updateDoctorVisit;

	}
	
	
	
	public void deleteDoctorVisit(Integer id) {
		
		doctorVisitRepository.deleteById(id);
	}
	
	
	
	
	
	public DoctorVisit getDoctorVisitById(Integer id) {
		
		Optional<DoctorVisit> optionalid=doctorVisitRepository.findById(id);
		return optionalid.get();
	}
	
	
}
