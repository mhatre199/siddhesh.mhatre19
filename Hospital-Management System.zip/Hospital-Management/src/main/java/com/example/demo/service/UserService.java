package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	public User saveUser(User user) {

		return userRepository.save(user);
	}

	public User updateUser(User user) {

		User existingUser = userRepository.findById(user.getId()).get();

		existingUser.setFirstName(user.getFirstName());
		existingUser.setLastName(user.getLastName());
		existingUser.setEmail(user.getEmail());
		existingUser.setCellNo(user.getCellNo());
		existingUser.setPassword(user.getPassword());

		User updateUser = userRepository.save(existingUser);

		return updateUser;
	}

	public void deleteUser(Integer id) {

		userRepository.deleteById(id);
	}

	public User getUserById(Integer id) {

		Optional<User> optionalid = userRepository.findById(id);

		return optionalid.get();
	}

//==============================================================================================

	public User updateUserById(Integer id, User user) {
		Optional<User> opUser = userRepository.findById(id);
		User dbUser = null;
		if (opUser.isPresent())
			dbUser = opUser.get();
		if (user.getFirstName() != null)
			dbUser.setFirstName(dbUser.getFirstName());
		if (user.getLastName() != null)
			dbUser.setLastName(dbUser.getLastName());
		if (user.getCellNo() != null)
			dbUser.setCellNo(dbUser.getCellNo());
		if (user.getEmail() != null)
			dbUser.setEmail(dbUser.getEmail());
		if (user.getRole() != null)
			dbUser.setRole(dbUser.getRole());
		if (user.getPassword() != null)
			dbUser.setPassword(dbUser.getPassword());
//		if (user.getId() != null)
//			dbUser.setId(dbUser.getId());

		return userRepository.save(dbUser);
	}

}
