package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.MedicineAssigned;
import com.example.demo.repository.MedicineAssignedRepository;

@Service
public class MedicineAssignedService {

	@Autowired
	private MedicineAssignedRepository medicineAssignedRepository;

	public List<MedicineAssigned> getAllMedicineAssigneds() {

		return medicineAssignedRepository.findAll();
	}

	public MedicineAssigned saveMedicineAssigned(MedicineAssigned medicineAssigned) {

		return medicineAssignedRepository.save(medicineAssigned);
	}

	public MedicineAssigned updateMedicineAssigned(MedicineAssigned medicineAssigned) {

		MedicineAssigned existingMedicineAssigned = medicineAssignedRepository.findById(medicineAssigned.getId()).get();

		existingMedicineAssigned.setPrescription(medicineAssigned.getPrescription());
		existingMedicineAssigned.setPrescription(medicineAssigned.getPrescription());

		MedicineAssigned updateMedicineAssigned = medicineAssignedRepository.save(existingMedicineAssigned);

		return updateMedicineAssigned;
	}

	public void deleteMedicineAssigned(Integer id) {

		medicineAssignedRepository.deleteById(id);
	}
	
	
	public MedicineAssigned getMedicineAssignedById(Integer id)
	
	{
		Optional<MedicineAssigned> optionalid=medicineAssignedRepository.findById(id);
		return optionalid.get();
	}
	
	

}
