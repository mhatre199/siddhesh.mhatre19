package com.example.demo.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "doctor_visits")
public class DoctorVisit {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String VdrName;

	public String getVdrName() {
		return VdrName;
	}

	public void setVdrName(String vdrName) {
		VdrName = vdrName;
	}

	public DoctorVisit(int id, String vdrName, Patient patient, Doctor doctor, int visits) {
		super();
		this.id = id;
		VdrName = vdrName;
		this.patient = patient;
		this.doctor = doctor;
		this.visits = visits;
	}

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "pat_id")
	private Patient patient;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "doctor_id")
	private Doctor doctor;
	private int visits;

	public DoctorVisit(int id, Patient patient, Doctor doctor, int visits) {
		super();
		this.id = id;
		this.patient = patient;
		this.doctor = doctor;
		this.visits = visits;
	}

	public DoctorVisit() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	public int getVisits() {
		return visits;
	}

	public void setVisits(int visits) {
		this.visits = visits;
	}

	@Override
	public String toString() {
		return "DoctorVisit [id=" + id + ", patient=" + patient + ", doctor=" + doctor + ", visits=" + visits + "]";
	}

}
