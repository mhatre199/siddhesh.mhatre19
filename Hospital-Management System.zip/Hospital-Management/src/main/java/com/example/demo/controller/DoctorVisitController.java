package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.DoctorVisit;
import com.example.demo.service.DoctorVisitService;

@RestController
@RequestMapping("/api")
public class DoctorVisitController {

	@Autowired
	private DoctorVisitService doctorVisitService;

	@GetMapping("/getAllDoctorVisits")
	public List<DoctorVisit> getAllDoctorVisits() {

		return doctorVisitService.getAllDoctorVisits();
	}

	@PostMapping("/saveDoctorVisit")
	public DoctorVisit saveDoctorVisit(DoctorVisit doctorVisit) {
		return doctorVisitService.saveDoctorVisit(doctorVisit);
	}

	@PutMapping("/updateDoctorVisit/{id}")
	public DoctorVisit updateDoctorVisit(@PathVariable("id") Integer id, @RequestBody DoctorVisit doctorVisit) {

		doctorVisit.setId(id);

		DoctorVisit updateDoctorVisit = doctorVisitService.saveDoctorVisit(doctorVisit);
		return updateDoctorVisit;
	}
	
	
	@DeleteMapping("/deleteDoctorVisit/{id}")
	public void deleteDoctorVisit(@PathVariable("id") Integer id ) {
		
		
		doctorVisitService.deleteDoctorVisit(id);
	}
	
	
	
	@GetMapping("/getDoctorVisitById/{id}")
	public DoctorVisit getDoctorVisitById(@PathVariable ("id") Integer id) {
		
		DoctorVisit doctorVisit =doctorVisitService.getDoctorVisitById(id);
		
		return doctorVisit;
	}
	
	
	
	

}
