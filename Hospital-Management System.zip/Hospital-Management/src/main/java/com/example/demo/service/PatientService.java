package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Patient;
import com.example.demo.repository.PatientRepository;

@Service
public class PatientService {

	@Autowired
	private PatientRepository patientRepository;

	public List<Patient> getAllPatients() {
		return patientRepository.findAll();
	}

	
	
	public Patient savePatient(Patient patient) {
		return patientRepository.save(patient);
	}

	
	
	
	public Patient updatePatient(Patient patient) {

		Patient existingPatient = patientRepository.findById(patient.getId()).get();

		existingPatient.setpName(patient.getpName());

		existingPatient.setDateOfAdmission(patient.getDateOfAdmission());
		existingPatient.setDob(patient.getDob());
		existingPatient.setGender(patient.getGender());
		existingPatient.setBloodGroup(patient.getBloodGroup());
		existingPatient.setPrescription(patient.getPrescription());
		existingPatient.setBedAlloted(patient.getBedAlloted());
		existingPatient.setPaymentStatus(patient.getPaymentStatus());
		existingPatient.setPatientProblem(patient.getPatientProblem());
		existingPatient.setAddress(patient.getAddress());

		Patient updatePatient = patientRepository.save(existingPatient);

		return updatePatient;
	}
	
	
	public void deletePatient(Integer id)
	{
		patientRepository.deleteById(id);
	}
	
	
	
	
	public Patient getPatientById(Integer id) {
		
		
		Optional<Patient> optionalid=patientRepository.findById(id);
		return optionalid.get();
	}
	
	
	
	
	
	

}
